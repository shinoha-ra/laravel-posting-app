        <footer class="d-flex justify-content-center align-items-center bg-light">
            <p class="text-muted small mb-0">&copy; 投稿アプリ All rights reserved.</p>
        </footer>