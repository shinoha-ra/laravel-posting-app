        <header>
            <nav class="navbar navbar-light bg-light">
                <div class="container">
                    <a href="<?php echo e(route('posts.index')); ?>" class="navbar-brand">投稿アプリ</a>

                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">ログアウト</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </nav>
        </header><?php /**PATH C:\work\pj2025-shinohara\xampp\htdocs\laravel-posting-app\resources\views/layouts/header.blade.php ENDPATH**/ ?>