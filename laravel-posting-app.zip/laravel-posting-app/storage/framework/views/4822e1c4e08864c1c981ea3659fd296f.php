<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\work\pj2025-shinohara\xampp\htdocs\laravel-posting-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>